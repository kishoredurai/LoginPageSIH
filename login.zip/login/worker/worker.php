<?php 
  include('../functions.php');
  include('header.php');
  include('sidebar.php');
  if (!isworker()) {
    $_SESSION['msg'] = "You must log in first";
    header('location: ../login.php');
  }

?>
  <?php  
 $connect = mysqli_connect("localhost", "root", "", "multi_login");  
 $query ="SELECT * FROM machine ;";  
 $result = mysqli_query($connect, $query);  
 $result2 = mysqli_query($connect, $query); 

 ?>
<!DOCTYPE html>
<html lang="en">

  <head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  
    <title> Worker - Dashboard</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body id="page-top">

   
    

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <div class="d-md-flex h-md-100 align-items-center">

<!-- First Half -->

<div class="col-md-6 p-0 bg-indigo h-md-100 p-3" >
<div class="border border-dark">
    <div class="d-md-flex align-items-center h-200 p-3 text-center justify-content-center">
        <div class="logoarea pt-5 pb-5">
        <div class="container">
              <form>
              <div class="row">
          <div class="col">      
          <div class="spinner-grow text-warning" style="width: 3rem; height: 3rem;"></div>
          </div>
          <div class="col">
          <div class="spinner-grow text-primary " style="width: 3rem; height: 3rem;"></div>
          </div>    
        </div>
<br><br>
        <div class="row">
          <div class="col">      
                  <label class="switch">
              <input type="checkbox">
              <span class="slider round"></span>
            </label>
          </div>
          <div class="col">
          <label class="switch">
              <input type="checkbox">
              <span class="slider round"></span>
            </label>
          </div>    
        </div>
        <div class="row">
          <div class="col">
                        
                  <label class="switch">
              <input type="checkbox">
              <span class="slider round"></span>
            </label>
          </div>
          <div class="col">
          <label class="switch">
              <input type="checkbox">
              <span class="slider round"></span>
            </label>
          </div>    
        </div>
      </form>
      
  <h2 style="border-style: groove;">MACHINE 1 STATUS</h2>
  
  <p>machine status and remote control, indication</p>            
  <table class="table table-dark table-hover table-bordered">
    <thead>
      <tr>
        <th>sn</th>
        <th>number</th>
        <th>status</th>
      </tr>
    </thead>

    <tbody>
                    <?php  
                          while($row = mysqli_fetch_array($result2))  
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$row["id"].'</td>  
                                    <td>machine1</td>  
                                    <td>'.$row["machine1"].'</td>  
                                   
                                    
                               </tr>  
                               ';  
                          }  
                          ?>  
     </tbody>
  </table>
</div>
        </div>
    </div>
</div>
</div>

<!-- Second Half -->
<div class="col-md-6 p-0 bg-indigo h-md-100 p-3">
<div class="border border-dark">
    <div class="d-md-flex align-items-center h-md-200 p-3 text-center justify-content-center">
    <div class="logoarea pt-5 pb-5">
    <div class="container">
    <form>
    <div class="row">
          <div class="col">      
          <div class="spinner-grow text-warning" style="width: 3rem; height: 3rem;"></div>
          </div>
          <div class="col">
          <div class="spinner-grow text-primary " style="width: 3rem; height: 3rem;"></div>
          </div>    
        </div>
<br><br>
        <div class="row">
          <div class="col">      
                  <label class="switch">
              <input type="checkbox">
              <span class="slider round"></span>
            </label>
          </div>
          <div class="col">
          <label class="switch">
              <input type="checkbox">
              <span class="slider round"></span>
            </label>
          </div>    
        </div>
        <div class="row">
          <div class="col">      
                  <label class="switch">
              <input type="checkbox">
              <span class="slider round"></span>
            </label>
          </div>
          <div class="col">
          <label class="switch">
              <input type="checkbox">
              <span class="slider round"></span>
            </label>
          </div>    
        </div>
      </form>
     
  <h2 style="border-style: groove;">MACHINE 2 STATUS</h2>
  <p>machine status and remote control, indication</p>            
  <table class="table table-dark table-hover table-bordered ">
    <thead>
      <tr>
        <th>sn</th>
        <th>number</th>
        <th>status</th>
      </tr>
    </thead>
   
    <tbody>
                    <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$row["id"].'</td>  
                                    <td>machine2</td>  
                                    <td>'.$row["machine2"].'</td>  
                                                                    
                               </tr>  
                               ';  
                          }  
                          ?>  
     </tbody>
  </table>

        </div>
    </div>
    </div>


</div>
        <!-- /.container-fluid -->


      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="worker.php?logout='1'">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>

  </body>

</html>
