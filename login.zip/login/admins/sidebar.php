<div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="admin.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i>
            <span> Users</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">users</h6>
            <a class="dropdown-item" href="insert.php"><i class="fas fa-user-plus"></i> Add User</a>
            
            <a class="dropdown-item" href="user.php"><i class="fas fa-users"></i> Manage users</a>
            
          
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="charts.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Charts</span></a>
        </li>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="machine.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Machine status</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="tables.php">
            <i class="fas fa-fw fa-table"></i>
            <span>User login Details</span></a>
        </li>
      </ul>

     