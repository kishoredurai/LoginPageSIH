<div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="manager.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
        
        
        </li>
        <li class="nav-item">
        <li class="nav-item active">
          <a class="nav-link" href="machine.php">
            <i class="fa fa-industry"></i>
            <span>Machine status</span></a>
        </li>
       
      </ul>

     